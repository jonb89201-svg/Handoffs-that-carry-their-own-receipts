Fixture, not a model answer (run 5b kit, 2026-09-30): every '- ' line is copied verbatim from kit SWE's ARM A
(kit_swe/KIT_swe.json; build_kit_swe.py --check asserts each one is a substring of the arm). It is the most the arm can score
under score_k2 if a model repeats it word for word.

1. Status:
- {"claim":"msrest #208: _FixedOffset made picklable with __reduce__; repo tests 77/77 pass (the patch replaced __repr__ to do it, so _FixedOffset lost its repr)","id":"INV-01","tag":"TERMINAL"}
- {"claim":"scadnano #288: IDT export handles Extension and Loopout domains; repo tests 353/353 pass (the agent never ran its own fix, and the patch adds a stray reproduce_bug.py)","id":"INV-02","tag":"TERMINAL"}
- {"claim":"django-environ #358: _cast_urlstr uses unquote, not unquote_plus, so '+' survives in DB passwords; repo tests 12/12 pass (the patch adds a duplicate urllib.parse import block)","id":"INV-03","tag":"TERMINAL"}
- "tag":"RESEARCH"
- {"claim":"formulaic #166: agent claimed a whitespace fix for transform_state; repo tests 2 failed, 45 passed","id":"INV-04","tag":"RESEARCH"}
- {"claim":"stix2 #74: agent claimed the Bundle custom-field bug resolved; no patch was submitted","id":"INV-05","tag":"RESEARCH"}
- {"claim":"artifactory #439: agent claimed a stat() fix; repo tests 12 failed, 47 passed","id":"INV-06","tag":"RESEARCH"}
- {"claim":"geopandas #1609: agent changed the to_file default driver to GPKG; not verified: the repo test file failed at collection and the results were never parsed","id":"INV-07","tag":"RESEARCH"}

2. Rejected:
- {"id":"REJ-01","path":"scadnano: reproducing with 'import sc'","reason_code":"DEAD_END_DOCUMENTED"}
- {"id":"REJ-02","path":"django-environ: importing _cast_urlstr from the top-level environ package","reason_code":"TEST_FAILED"}
- {"id":"REJ-03","path":"formulaic: stripping the formula string in Formula._prepare_item","reason_code":"TEST_FAILED"}
- {"id":"REJ-04","path":"stix2: reproducing with self-written Vulnerability and Bundle stand-in classes","reason_code":"FALSE_POSITIVE_PATTERN"}
- {"id":"REJ-05","path":"artifactory: reproducing against artifactory.domain.com","reason_code":"PLATFORM_BLOCKED"}
- {"id":"REJ-06","path":"artifactory: running a local Artifactory in docker","reason_code":"PLATFORM_BLOCKED"}
- {"id":"REJ-07","path":"artifactory: collapsing '//' to '/' in the stat URL","reason_code":"TEST_FAILED"}
- {"id":"REJ-08","path":"geopandas: checking to_file with a script under pandas 2.2.2","reason_code":"PLATFORM_BLOCKED"}
- {"id":"REJ-09","path":"remerkleable: file-by-file scroll search for the Container class","reason_code":"DEAD_END_DOCUMENTED"}
- {"id":"REJ-10","path":"TexSoup: searching for 'class TexSoup'","reason_code":"DEAD_END_DOCUMENTED"}
- {"id":"REJ-11","path":"TexSoup: web search via search_web, curl and wget","reason_code":"PLATFORM_BLOCKED"}
- {"id":"REJ-12","path":"flake8-bugbear: the B900 duplicate-except check as first written","reason_code":"TEST_FAILED"}
- {"id":"REJ-13","path":"SPF2IP: applying the issue's one-line fix with the edit tool","reason_code":"PLATFORM_BLOCKED"}

3. Open:
- {"blocker":"Container class not located yet","id":"OPEN-01","target":"remerkleable #2: validate field names when a Container is initialised"}
- {"blocker":"fix site not traced in the tokenizer","id":"OPEN-02","target":"TexSoup #140: keep the newline after a backslash (bug reproduced)"}
- {"blocker":"check does not fire; bugbear.py grew from 1221 to 1629 lines and needs review","id":"OPEN-03","target":"flake8-bugbear #284: flag duplicate except clauses (B900)"}
- {"blocker":"edit tool rejects the fix on indentation (E111)","id":"OPEN-04","target":"SPF2IP #3: fix empty answers on Python 3.6 (the issue gives the one-line fix)"}
- {"blocker":"2 repo tests fail; the second edit was never run","id":"OPEN-05","target":"formulaic #166: transform_state empty when the formula has extra spaces"}
- {"blocker":"never reproduced against the real stix2 library; no patch","id":"OPEN-06","target":"stix2 #74: Bundle with custom fields on an SDO"}
- {"blocker":"cannot reproduce: the example host does not resolve and there is no docker; the submitted patch fails 12 tests and should be reverted","id":"OPEN-07","target":"artifactory #439: stat() on paths that repeat the hostname"}
- {"blocker":"verification incomplete: test collection error, results unparsed","id":"OPEN-08","target":"geopandas #1609: GPKG as the default to_file driver"}

4. NOT IN HANDOFF

5. NOT IN HANDOFF

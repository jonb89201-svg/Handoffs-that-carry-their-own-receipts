#!/usr/bin/env python3
"""Reproduce kit SWE's issue selection from the public dataset (network; ~90 MB shard). The rule was fixed before any
trajectory was read in detail: model swe-agent-llama-70b, 25-70 steps, one issue per repo, ranked by
sha256(instance_id + "rrc5b"); first 3 resolved (target, submitted), 4 submitted-not-resolved, 4 exit_context; no repo twice.

    uv run --with pyarrow --with pandas --with huggingface_hub python3 select_swe.py
"""
import hashlib
import pandas as pd
from huggingface_hub import hf_hub_download

REV = "68195a1450865274106246d0d0296a1d6807b88e"
f = hf_hub_download("nebius/SWE-agent-trajectories", "data/train-00000-of-00012.parquet", repo_type="dataset", revision=REV)
df = pd.read_parquet(f)
df = df[df.model_name == "swe-agent-llama-70b"].copy()
df["steps"] = df.trajectory.map(len)
df = df[df.steps.between(25, 70)]
df["repo"] = df.instance_id.str.split("__").str[0]
df["h"] = df.instance_id.map(lambda s: hashlib.sha256((s + "rrc5b").encode()).hexdigest())
df = df.sort_values("h")
used = set()
for name, mask, k in (("RESOLVED", df.target & (df.exit_status == "submitted"), 3),
                      ("CLAIMED_NOT_RESOLVED", ~df.target & (df.exit_status == "submitted"), 4),
                      ("OPEN_CONTEXT", df.exit_status == "exit_context", 4)):
    n = 0
    for _, r in df[mask].iterrows():
        if r.repo in used:
            continue
        used.add(r.repo); n += 1
        print(f"{name} {r.instance_id} steps={r.steps}")
        if n == k:
            break

# Kit SWE — source notes (where each fact comes from)

Source: `nebius/SWE-agent-trajectories` revision `68195a14…`, shard `data/train-00000-of-00012.parquet`, model
`swe-agent-llama-70b` (CC BY 4.0; model outputs also under the Llama 3.1 license). Selection: `select_swe.py` (rule in its
docstring, fixed before any trajectory was read in detail). Read by hand by Tally (RRC seat; model Opus 5.5 in this session
since 2026-09-30), 2026-09-30. "Step" = index in the trajectory list (0 = system prompt, 1 = issue). No trajectory text is
reproduced in the kit beyond short identifiers and error names.

| Item | Instance | Evidence |
|---|---|---|
| INV-01 | Azure__msrest-for-python-208 | step 18 adds `__reduce__` over the `__repr__` line (patch shows `- def __repr__` / `+ def __reduce__`); step 21 own repro prints both datetimes; eval: 77 passed |
| INV-02 | UC-Davis…scadnano-python-package-288 | steps 7, 27 `ModuleNotFoundError: No module named 'sc'`; steps 20, 36 edit `vendor_dna_sequence` for Extension, Loopout; patch adds `reproduce_bug.py`; eval: 353 passed |
| INV-03 | joke2k__django-environ-358 | step 12 inserts a second `from urllib.parse import (...)` block; step 14 `unquote`; eval: 12 passed |
| INV-04 / REJ-03 / OPEN-05 | matthewwardrop__formulaic-166 | step 26 strip in `Formula._prepare_item`; step 29 repro still `{}`; step 40 `formula.replace(" ", "")` in `get_terms`; steps 43–57 `reproduce.py` not found (wrong directory), never re-run; eval: 2 failed (`test_quoted_python_args`, `test_nested_transform_state`), 45 passed |
| INV-05 / REJ-04 / OPEN-06 | oasis-open__cti-python-stix2-74 | steps 10–15 self-written `Vulnerability` / `Bundle` classes; step 40 "resolved"; `generated_patch` empty; no eval log |
| INV-06 / REJ-05, 06, 07 / OPEN-07 | devopshq__artifactory-439 | step 7 name resolution fails; step 9 `docker: command not found`; step 30 `url.replace("//", "/")`; eval: 12 failed, 47 passed. "Breaks https://" is DERIVED from the code (the joined URL begins with the drive `https://…`), not from a log |
| INV-07 / REJ-08 / OPEN-08 | geopandas__geopandas-1609 | step 12 default driver `GPKG`; steps 19–35 `module 'pandas' has no attribute 'Int64Index'` (pandas 2.2.2, step 25); eval: `1 error during collection`, then the harness's log parser raised `KeyError` |
| REJ-09 / OPEN-01 | protolambda__remerkleable-2 | steps 6–68 open/scroll core, tree, complex (to ~line 490 of 878), basic, subtree, virtual, history, bitfields, byte_arrays; exit_context |
| REJ-10, 11 / OPEN-02 | alvinwan__TexSoup-140 | step 7 bug reproduced (`a\b`); step 9 no `class TexSoup`; step 15 `__init__.py` docstring: TexSoup is a function; steps 42–52 `search_web` not found, curl failed, wget HTML; exit_context |
| REJ-12 / OPEN-03 | PyCQA__flake8-bugbear-284 | step 21 file 1221 → 1629 lines after the header edit; step 27 `flake8 test_b900.py` prints nothing; exit_context |
| REJ-13 / OPEN-04 | nathandines__SPF2IP-3 | steps 6–44: 20 edit attempts, each rejected with `E111 indentation is not a multiple of 4`; the issue text contains the diff; exit_context |
| DEC-01 | (handoff rule) | written by the handoff author; matches how the dataset labels `target` |
| DEC-02 | artifactory steps 7, 9; TexSoup steps 45–47 | the issue's example host does not resolve; no docker. NOT "no network": in TexSoup, wget reached a search engine (step 47). Corrected before registration (an earlier draft of the kit said "no network") |

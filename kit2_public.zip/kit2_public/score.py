#!/usr/bin/env python3
"""
kit scorer — mechanical part of the rubric.

Splits a raw answer into Q1..Q5 by its numbered headings, then matches each key item by distinctive
keywords (so prose answers without IDs score the same as ID tables). Reason/blocker credit = the reason
code OR a plain-language synonym (Arm B's memo carries no codes). The synonym lists are the seat's
judgment and are fixed here, before Arm B/C are scored.

Q1 and Q5 need judgment (is an item *claimed* TERMINAL; is a step *consistent*): the scorer extracts
the evidence, the seat records the call in RESULTS with the reason.

Usage: python3 score.py answers/<answer>.md
"""

from __future__ import annotations

import re
import sys

# Kit-1 item lists (private audit targets) removed for publication; score_k2.activate() installs kit 2's.
REJ = []
OPEN = []


def split_questions(text):
    """Q sections keyed 1..5, from headings like '### 1.', '**1.', '1)' or 'Q1' at line start."""
    # strong headings first ('### 1.', '**1.', 'Q1'); bare '1.' only as a fallback, since a numbered
    # list inside an answer (Q2's paths) would otherwise be read as the next question
    strong = r"(?im)^\s*(?:#+\s*(?:Q|Question\s*)?|\*\*\s*(?:Q|Question\s*)?|Q|Question\s*)([1-5])[.):*\s]"
    marks = [(m.start(), int(m.group(1))) for m in re.finditer(strong, text)]
    if len({q for _, q in marks}) < 5:
        marks = [(m.start(), int(m.group(1))) for m in re.finditer(r"(?im)^\s*([1-5])[.):]", text)]
    out, seen = {}, set()
    for i, (pos, q) in enumerate(marks):
        if q in seen:
            continue
        seen.add(q)
        end = next((p for p, qq in marks[i + 1:] if qq not in seen), len(text))
        out[q] = text[pos:end]
    return out


def lines_matching(sec, kw):
    return [ln for ln in sec.splitlines() if re.search(kw, ln, re.I)]


def unescape_md(text):
    """Models often emit Markdown-escaped text (DEAD\\_END\\_DOCUMENTED). Match on what a reader sees."""
    return re.sub(r"\\([_*`\[\]()#.!-])", r"\1", text)


def score_list(sec, items):
    sec = unescape_md(sec)
    hit = reason = 0
    rows = []
    for iid, kw, syn in items:
        ls = lines_matching(sec, kw) + lines_matching(sec, re.escape(iid))
        found = bool(ls)
        ok = found and any(re.search(syn, ln, re.I) for ln in ls)
        hit += found
        reason += ok
        rows.append((iid, found, ok))
    return hit, reason, rows


def main(path):
    text = open(path, encoding="utf-8").read()
    qs = split_questions(text)
    print(f"== {path}   sections found: {sorted(qs)}")
    missing = [q for q in range(1, 6) if q not in qs]
    if missing:
        print(f"  !! sections not found: {missing} — split by hand before trusting scores")

    q2h, q2r, rows2 = score_list(qs.get(2, ""), REJ)
    q3h, q3b, rows3 = score_list(qs.get(3, ""), OPEN)
    print(f"Q2 rejected recall {q2h}/13, reason correct {q2r}/13")
    for iid, f, ok in rows2:
        if not (f and ok):
            print(f"   {iid}: {'found, reason MISSING' if f else 'NOT FOUND'}")
    print(f"Q3 open recall {q3h}/8, blocker correct {q3b}/8")
    for iid, f, ok in rows3:
        if not (f and ok):
            print(f"   {iid}: {'found, blocker MISSING' if f else 'NOT FOUND'}")

    # Q4: only the numbered list counts (a trailing "also closed" note is not one of the three)
    q4 = qs.get(4, "")
    listed = "\n".join(ln for ln in q4.splitlines() if re.match(r"\s*(\d+[.)]|[-*])\s", ln))
    q4h, q4r, rows4 = score_list(listed or q4, REJ)
    print(f"Q4 don't-retry items that are real rejected paths: {q4h} (reason correct {q4r}); "
          f"ids {[i for i, f, _ in rows4 if f]}")

    q1 = qs.get(1, "")
    print("Q1 ids mentioned:", sorted(set(re.findall(r"INV-[ACG]0\d", q1))),
          "| mentions 'terminal':", len(re.findall(r"terminal", q1, re.I)))
    print("Q5 text:", " ".join(qs.get(5, "").split())[:400])
    return {"q2": (q2h, q2r), "q3": (q3h, q3b), "q4": (q4h, q4r)}


if __name__ == "__main__":
    for p in sys.argv[1:]:
        main(p)

#!/usr/bin/env python3
"""Scorer patterns for kit SWE (run 5b, kit_swe/), frozen BEFORE any run-5b answer exists. Same machinery as kit 1
(score.score_list line matching, batch_score.score_answer metrics); only the item lists change. The kit-1 lists are
restored by deactivate(), so kit-1 scoring is untouched.

Use: `import score_k2; score_k2.activate()` before batch_score.load_runs(...) on a run-5b answer dir; `deactivate()` after.
A line credits an item when it names the item (path/target keywords, or its ID) AND gives its reason/blocker (the reason
code or a plain-language synonym), exactly as in kit 1.
"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import batch_score, score  # noqa: E402

REJ = [  # id, path keywords, reason synonyms
    ("REJ-01", r"import sc\b|module.{0,8}\bsc\b|scadnano", r"dead.?end|modulenotfound|no module|not found|import (fail|error)|cannot import"),
    ("REJ-02", r"_cast_urlstr|environ package|top.?level environ|from environ", r"test.?failed|importerror|cannot import|environ\.environ|lives in"),
    ("REJ-03", r"_prepare_item|formulaic", r"test.?failed|still print|still (empty|returned|produc)|empty (dict|\{\})|\{\}|did not (help|fix|work)"),
    ("REJ-04", r"stand.?in|mock|self.?written|stix2", r"false.?positive|stand.?ins? pass|never exercis|not exercis|library (was )?never|mock"),
    ("REJ-05", r"domain\.com|dns|real (artifactory|server)", r"platform.?blocked|dns|resol|no network|network"),
    ("REJ-06", r"docker", r"platform.?blocked|not (available|found|installed)|unavailable|command not found|no docker"),
    ("REJ-07", r"//|double.?slash|collaps", r"test.?failed|\b12\b|tests? fail|https"),
    ("REJ-08", r"int64index|pandas 2\.2|geopandas", r"platform.?blocked|int64index|no int64|pandas 2\.2"),
    ("REJ-09", r"remerkleable|container", r"dead.?end|context|ran out|exhaust|line 490|490"),
    ("REJ-10", r"class texsoup", r"dead.?end|no such class|not a class|is a function|function"),
    ("REJ-11", r"web search|wget|curl|search_web", r"platform.?blocked|missing|not found|raw|html|did not work|failed"),
    ("REJ-12", r"b900|bugbear|duplicate.?except", r"test.?failed|printed nothing|no output|does not fire|did not fire|doesn.?t fire|nothing"),
    ("REJ-13", r"spf2ip|edit tool", r"platform.?blocked|e111|indent|lint"),
]
OPEN = [  # id, target keywords, blocker synonyms
    ("OPEN-01", r"remerkleable|container", r"not (yet )?located|not located yet|not (yet )?found|locat"),
    ("OPEN-02", r"texsoup|backslash", r"fix site|not (yet )?traced|tokeni[sz]er|trace"),
    ("OPEN-03", r"bugbear|b900|duplicate.?except", r"does not fire|not fir|1629|needs review|review"),
    ("OPEN-04", r"spf2ip|python 3\.6", r"e111|indent|edit tool"),
    ("OPEN-05", r"formulaic|transform_state", r"tests? fail|failing|never (been )?run|second edit"),
    ("OPEN-06", r"stix2|bundle", r"never reproduc|not reproduc|real stix2|no patch"),
    ("OPEN-07", r"artifactory|stat\(\)", r"reproduc|network|docker|revert|12 tests"),
    ("OPEN-08", r"geopandas|gpkg|to_file", r"collection|unparsed|not parsed|incomplete|verification"),
]
TERMINAL_REQUIRED = [r"msrest|picklab|_fixedoffset|INV-01", r"scadnano|loopout|INV-02", r"django-environ|_cast_urlstr|unquote|INV-03"]
RESEARCH_ITEMS = {"INV-04": r"formulaic|transform_state", "INV-05": r"stix2|bundle", "INV-06": r"artifactory",
                  "INV-07": r"geopandas|gpkg"}
NEXT_OK = r"spf2ip|python 3\.6|OPEN-04"
NEXT_JUSTIFIED = r"revert|artifactory|formulaic|texsoup|tokeni[sz]er"

_K1 = {}


def activate():
    if not _K1:
        _K1.update(REJ=list(score.REJ), OPEN=list(score.OPEN), TERMINAL_REQUIRED=list(batch_score.TERMINAL_REQUIRED),
                   RESEARCH_ITEMS=dict(batch_score.RESEARCH_ITEMS), NEXT_OK=batch_score.NEXT_OK, NEXT_JUSTIFIED=batch_score.NEXT_JUSTIFIED)
    score.REJ[:] = REJ; score.OPEN[:] = OPEN                      # in place: batch_score holds the same list objects
    batch_score.TERMINAL_REQUIRED[:] = TERMINAL_REQUIRED
    batch_score.RESEARCH_ITEMS = dict(RESEARCH_ITEMS)
    batch_score.NEXT_OK, batch_score.NEXT_JUSTIFIED = NEXT_OK, NEXT_JUSTIFIED


def deactivate():
    if not _K1:
        return
    score.REJ[:] = _K1["REJ"]; score.OPEN[:] = _K1["OPEN"]
    batch_score.TERMINAL_REQUIRED[:] = _K1["TERMINAL_REQUIRED"]
    batch_score.RESEARCH_ITEMS = dict(_K1["RESEARCH_ITEMS"])
    batch_score.NEXT_OK, batch_score.NEXT_JUSTIFIED = _K1["NEXT_OK"], _K1["NEXT_JUSTIFIED"]


def fixture_ceiling(path, arm_text):
    """Every '- ' clause of the fixture must be verbatim in the arm's text; score the fixture under kit-SWE patterns."""
    text = open(path, encoding="utf-8").read()
    clauses = [ln[2:] for ln in text.splitlines() if ln.startswith("- ")]
    missing = [c for c in clauses if c not in arm_text]
    assert not missing, f"fixture clauses not verbatim in the arm: {missing}"
    activate()
    try:
        qs = score.split_questions(text)
        h2, r2, _ = score.score_list(qs[2], score.REJ)
        h3, b3, _ = score.score_list(qs[3], score.OPEN)
        q1, ft = batch_score.q1_eval(qs[1])
    finally:
        deactivate()
    return {"clauses": len(clauses), "h2": h2, "r2": r2, "h3": h3, "b3": b3, "q1": q1, "ft": ft}


def selftest():
    """Kit-1 behaviour is restored exactly; kit-SWE patterns do not credit a kit-1 answer, and vice versa."""
    k1 = (list(score.REJ), list(score.OPEN), list(batch_score.TERMINAL_REQUIRED), dict(batch_score.RESEARCH_ITEMS),
          batch_score.NEXT_OK)
    a1 = open(os.path.join(HERE, "answers", "A_grok.md"), encoding="utf-8").read()   # a real kit-1 frontier answer
    before = batch_score.score_answer(a1)
    activate(); cross = batch_score.score_answer(a1); deactivate()
    after = batch_score.score_answer(a1)
    assert (list(score.REJ), list(score.OPEN), list(batch_score.TERMINAL_REQUIRED), dict(batch_score.RESEARCH_ITEMS),
            batch_score.NEXT_OK) == k1, "kit-1 patterns not restored"
    assert before == after, "kit-1 scoring changed after an activate/deactivate cycle"
    assert cross["q2_recall"] == 0 and cross["q3_recall"] == 0 and cross["q1"] == 0, f"kit-1 answer credited under kit SWE: {cross}"
    print(f"SCORE_K2 SELFTEST OK: kit-1 answer {before['accuracy']:.2f} before/after, {cross['accuracy']:.2f} under kit-SWE patterns")


if __name__ == "__main__":
    selftest() if "--selftest" in sys.argv else sys.exit(__doc__)

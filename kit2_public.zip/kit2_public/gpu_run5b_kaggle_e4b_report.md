# Cold-seat GPU run: batch score

Model(s): google/gemma-4-E4B-it · answers: 60 · arms: A=20, C=20, P=20 · bootstrap seed 7

## Handoff cost (MEASURED: the model's own tokenizer, prompt incl. questions)

| arm | tokens_in | answers | truncated |
|---|---|---|---|
| A | 1500 | 20 | 0 |
| C | 191 | 20 | 0 |
| P | 1208 | 20 | 0 |

## Per-arm means, 95% bootstrap CI

| metric | A | C | P |
|---|---|---|---|
| accuracy | 0.91 [0.89, 0.94] | 0.00 [0.00, 0.00] | 0.86 [0.84, 0.88] |
| accuracy_noQ5 | 0.89 [0.86, 0.93] | 0.00 [0.00, 0.00] | 0.82 [0.80, 0.85] |
| q1 | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 1.00 [1.00, 1.00] |
| false_terminal | 0.00 [0.00, 0.00] | 0.00 [0.00, 0.00] | 0.00 [0.00, 0.00] |
| q2_recall | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 0.68 [0.50, 0.85] |
| q2_reason | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 0.66 [0.47, 0.84] |
| q3_recall | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 1.00 [1.00, 1.00] |
| q3_blocker | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 1.00 [1.00, 1.00] |
| q4_valid | 0.57 [0.43, 0.70] | 0.00 [0.00, 0.00] | 0.62 [0.48, 0.75] |
| q5 | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 1.00 [1.00, 1.00] |
| q5_refused | 0.00 [0.00, 0.00] | 0.05 [0.00, 0.15] | 0.00 [0.00, 0.00] |
| revival | 1.00 [1.00, 1.00] | 0.00 [0.00, 0.00] | 1.00 [1.00, 1.00] |
| specifics | 21.00 [21.00, 21.00] | 0.00 [0.00, 0.00] | 16.85 [14.50, 19.00] |
| tokens_out | 1120 [1086, 1156] | 6 [5, 10] | 1001 [918, 1076] |

Scope per arm: A=full, C=full, P=full

## Honesty notes
- q1, false_terminal, q5, revival are HEURISTIC (pattern-based). Spot-check the CSV before quoting them.
- Arm C `specifics` = rejected/open items it named. Its handoff contained none, so each one is invented.
- Answers with sections < 5 were split badly or truncated. Hand-split before trusting them.
- Answers with <5 sections: 19 of 60.

#!/usr/bin/env python3
"""
RRC cold-seat at scale on free GPU (Kaggle 30 h/wk, HF). Same model on every arm, so the model x arm
confound of the chat runs is gone, and N samples per arm instead of one.

Prompts come straight from grok_kit/KIT_PASTE.md (single source; the kit stays frozen). The answer key
never enters this script or the notebook: scoring happens afterwards with score.py, in the sandbox.

Per sample it records the model's OWN token counts (prompt in, answer out), so the token side of the
lease claim is measured on the model that actually ran, not estimated.

Kaggle / HF: keep the notebook and any dataset PRIVATE (proprietary; the frontier is internal state).
Model: google/gemma-4-E4B-it (Apache-2.0), loaded per its model card; sampling per card (T=1.0, top_p .95, top_k 64), thinking off.
Usage:
  python3 gpu_coldseat.py --dry                       # parse the kit, show prompts' sizes, no model
  python3 gpu_coldseat.py --model <hf id> --n 20      # writes runs/<model>/<arm>_<i>.md + manifest.jsonl
  python3 score.py runs/<model>/*.md                  # score afterwards (key stays out of the GPU box)
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.join(HERE, "..", "grok_kit", "KIT_PASTE.md")


def load_kit(path=KIT):
    if path.endswith(".json"):                                  # kit v2: {"questions": str, "arms": {letter: handoff}}
        k = json.load(open(path, encoding="utf-8"))
        return k["arms"], k["questions"]
    t = open(path, encoding="utf-8").read()
    q = re.search(r"## Questions[^\n]*\n(.*?)\n## Send back", t, re.S).group(1).strip()
    a = re.search(r"## ARM A[^\n]*\n```json\n(.*?)\n```", t, re.S).group(1).strip()
    b = re.search(r"## ARM B[^\n]*\n(.*)$", t, re.S).group(1).strip()
    c = re.search(r'Paste ONLY this sentence, then the questions:\s*\n\s*"(.*?)"', t, re.S).group(1).strip()
    return {"A": a, "B": b, "C": c}, q


def prompt(handoff, questions):
    return f"{handoff}\n\n{questions}"


# Gemma 4 12B/26B/31B with thinking OFF still emit an EMPTY thought block before the answer
# ("<|channel>thought\n<channel|>"; the E2B/E4B do not — model card, "Disabled Thinking Behavior").
# skip_special_tokens may drop the tags and leave a bare "thought\n". Strip only an EMPTY block; a block
# with content is left in place (that would be a finding, not noise). Recorded per sample in the manifest.
EMPTY_THOUGHT = re.compile(r"^\s*(?:<\|channel>thought[ \t]*\n[ \t]*<channel\|>|thought[ \t]*\n)[ \t]*\n?")


def strip_empty_thought(text: str) -> tuple[str, bool]:
    m = EMPTY_THOUGHT.match(text)
    return (text[m.end():], True) if m else (text, False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="google/gemma-4-E4B-it")   # what runs 1-3c and 4 ran (audit F7, 2026-09-30)
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--temperature", type=float, default=1.0)
    ap.add_argument("--max-new", type=int, default=1500)
    ap.add_argument("--arms", default="ABC")
    ap.add_argument("--out", default=os.path.join(HERE, "runs"))
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--n-per-arm", default="", help="e.g. A=5,D=20 (overrides --n for those arms)")
    ap.add_argument("--kit", default=KIT, help="path to KIT_PASTE.md (on Kaggle: wherever you uploaded it)")
    ap.add_argument("--dtype", default="auto", choices=["auto", "float16", "bfloat16"],   # every recorded run used auto
                    help="T4 has no native bf16: try auto first; if slow or NaN, compare float16")
    ap.add_argument("--gpu-mem", default="14GiB", help="per-GPU weight cap; lower it (e.g. 10GiB) so long prompts have room")
    ap.add_argument("--load-4bit", action="store_true",
                    help="bitsandbytes nf4 4-bit load (Turing/T4-compatible). Use for the 31B DENSE model on Kaggle 2xT4. "
                         "Do NOT combine with an already-quantized checkpoint (e.g. *-qat-w4a16-*): those carry their own "
                         "quantization and need an Ampere+ GPU for their kernels.")
    a = ap.parse_args()

    arms, questions = load_kit(a.kit)
    n_for = {k: int(v) for k, v in (kv.split("=") for kv in a.n_per_arm.split(",") if kv)}
    if a.dry:
        for k in a.arms:
            p = prompt(arms[k], questions[k] if isinstance(questions, dict) else questions)
            print(f"arm {k}: {len(p):>6} chars | n={n_for.get(k, a.n)} | first: {arms[k][:60]!r}")
        qs = questions.values() if isinstance(questions, dict) else [questions]
        print(f"questions: {sorted({q.count(chr(10)) + 1 for q in qs})} lines")
        cases = {"<|channel>thought\n<channel|>1. **Q1**": ("1. **Q1**", True),
                 "thought\n1. Q1": ("1. Q1", True),
                 "<|channel>thought\nreal reasoning<channel|>1. Q1": (None, False),   # content: NOT stripped
                 "1. Q1 thought": (None, False)}
        for raw, (want, flag) in cases.items():
            got, f = strip_empty_thought(raw)
            assert f == flag and (want is None or got == want), (raw, got, f)
        print("thought-strip selftest OK (4 cases)")
        print("KIT OK")
        return

    import time
    import torch
    t0 = time.time()
    stamp = lambda msg: print(f"[t+{time.time() - t0:6.0f}s] {msg}", flush=True)  # noqa: E731
    env = {"utc_start": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0)), "python": sys.version.split()[0]}
    for mod in ("torch", "transformers", "accelerate", "compressed_tensors", "bitsandbytes"):
        try:
            env[mod] = __import__(mod).__version__
        except Exception:          # not installed on this box: record that, don't guess
            env[mod] = None
    stamp(f"ENV {json.dumps(env, sort_keys=True)}")      # absolute UTC + versions in the log (the job logs had neither)
    stamp(f"GPUs visible: {torch.cuda.device_count()} {[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]}")
    if torch.cuda.device_count() == 0:
        raise SystemExit("NO GPU — set Accelerator to GPU T4 x2 (Kaggle) or attach an Ampere+ GPU (HF)")
    # Compute capability gates which quantization kernels run: compressed-tensors w4a16 needs Ampere (sm_80+).
    caps = [torch.cuda.get_device_capability(i) for i in range(torch.cuda.device_count())]
    ampere = min(caps) >= (8, 0)
    stamp(f"compute capability: {caps} -> {'Ampere+' if ampere else 'PRE-AMPERE (Turing/Pascal)'}")
    is_prequant = bool(re.search(r"w4a16|w8a|qat|-ct\b|compressed", a.model, re.I))
    if is_prequant and not ampere:
        raise SystemExit(
            f"FAIL-CLOSED: '{a.model}' looks like a compressed-tensors/w4a16 checkpoint, whose kernels need an "
            f"Ampere+ GPU (sm_80+). This box is {caps}. Options: (1) run this on an HF A10G/A100 Space, or "
            f"(2) on Kaggle 2xT4 use the DENSE model with --load-4bit (e.g. google/gemma-4-31b-it), which is a "
            f"proxy for the QAT checkpoint, not the exact one. Not faking a green.")
    if a.load_4bit and is_prequant:
        raise SystemExit("--load-4bit on an already-quantized checkpoint is a double-quant error; drop --load-4bit "
                         "and run the checkpoint natively on an Ampere+ GPU, or point --model at the DENSE variant.")
    # Official Gemma 4 loading (model card): processor + AutoModelForMultimodalLM
    from transformers import AutoProcessor, AutoModelForMultimodalLM
    proc = AutoProcessor.from_pretrained(a.model)
    quant = None
    if a.load_4bit:
        from transformers import BitsAndBytesConfig
        quant = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                   bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
        stamp("loading in bitsandbytes nf4 4-bit (Turing/T4-compatible)")
    stamp("processor loaded; loading model weights")
    # hard per-GPU memory caps: nothing may spill to disk (that is what made the first run crawl)
    max_mem = {i: a.gpu_mem for i in range(torch.cuda.device_count())}   # headroom for long prompts' attention
    max_mem["cpu"] = "20GiB"
    # transformers 5.17: passing quantization_config=None EXPLICITLY makes from_pretrained skip the checkpoint's own
    # quantizer (bisected 2026-09-29 on a packed w4a16 test model; job 6abbdd1b loaded the 31B QAT as dense random
    # weights, 62 GiB, and was cancelled). Pass the kwarg only when we actually have one.
    load_kw = dict(dtype=a.dtype if a.dtype == "auto" else getattr(torch, a.dtype), device_map="auto", max_memory=max_mem,
                   output_loading_info=True)
    if quant is not None:
        load_kw["quantization_config"] = quant
    model, load_info = AutoModelForMultimodalLM.from_pretrained(a.model, **load_kw)
    missing = sorted(load_info.get("missing_keys", []))
    if missing:
        raise SystemExit(f"FAIL-CLOSED: {len(missing)} checkpoint tensors MISSING after load (first: {missing[:3]}). "
                         "A model with newly initialised weights is not the model; not generating.")
    where = sorted({str(v) for v in getattr(model, "hf_device_map", {"all": "cuda"}).values()})
    stamp(f"model loaded; placed on {where}" + ("  !! WARNING: part of the model is OFF the GPU (slow)"
                                              if any(w in ("cpu", "disk") for w in where) else ""))
    qc = getattr(model.config, "quantization_config", None)
    qm = (qc.get("quant_method") if isinstance(qc, dict) else getattr(qc, "quant_method", None)) if qc else None
    if qm == "compressed-tensors":
        # transformers keeps int4 compressed-tensors weights packed at load and DECOMPRESSES them to the model dtype on
        # the first forward pass (optimized kernels: FP8 only). Memory at the first token ~ 2 bytes/param, not the file size.
        stamp("compressed-tensors checkpoint: weights decompress to the model dtype on the first forward pass "
              "(~2 bytes/param). The peak below is the real footprint; a load that fits is not a run that fits.")
    peak = lambda: [round(torch.cuda.max_memory_allocated(i) / 2**30, 1) for i in range(torch.cuda.device_count())]  # noqa: E731
    stamp(f"GPU peak after load (GiB): {peak()}")
    out = os.path.join(a.out, a.model.replace("/", "__"))
    os.makedirs(out, exist_ok=True)
    json.dump(env, open(os.path.join(out, "env.json"), "w"), indent=1, sort_keys=True)
    man = open(os.path.join(out, "manifest.jsonl"), "a")
    for k in a.arms:
        q = questions[k] if isinstance(questions, dict) else questions      # kit v3: per-arm question sets
        msgs = [{"role": "user", "content": prompt(arms[k], q)}]
        inputs = proc.apply_chat_template(msgs, tokenize=True, return_dict=True, return_tensors="pt",
                                          add_generation_prompt=True, enable_thinking=False).to(model.device)
        n_in = inputs["input_ids"].shape[-1]
        for i in range(n_for.get(k, a.n)):
            torch.manual_seed(1000 + i)                    # same seeds across arms
            t1 = time.time()
            g = model.generate(**inputs, max_new_tokens=a.max_new, do_sample=True,
                               temperature=a.temperature, top_p=0.95, top_k=64)   # card's recommended sampling
            ans_ids = g[0, n_in:]
            ans, stripped = strip_empty_thought(proc.decode(ans_ids, skip_special_tokens=True))
            fn = os.path.join(out, f"{k}_{i:03d}.md")
            open(fn, "w", encoding="utf-8").write(ans)
            rec = {"arm": k, "i": i, "seed": 1000 + i, "model": a.model, "tokens_in": int(n_in),
                   "tokens_out": int(ans_ids.shape[0]), "truncated": int(ans_ids.shape[0]) >= a.max_new,
                   "empty_thought_stripped": stripped, "file": os.path.basename(fn)}
            man.write(json.dumps(rec) + "\n")
            man.flush()
            rec["seconds"] = round(time.time() - t1, 1)
            print(rec, f"~{rec['tokens_out'] / max(rec['seconds'], 0.1):.1f} tok/s", flush=True)
            if i == 0:
                stamp(f"GPU peak after first answer of arm {k} (GiB): {peak()}")   # evidence of the real footprint
    stamp(f"DONE. answers in {out}; GPU peak (GiB): {peak()}")


if __name__ == "__main__":
    main()

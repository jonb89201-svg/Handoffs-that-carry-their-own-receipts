# Kit 2 (SWE-agent sessions) — public reproduction bundle

Reproduces the run 5b kit-2 result from "Handoffs that carry their own receipts": Gemma 4 E4B,
arms A (RRC frontier), P (complete prose) and C (no memory), 20 answers each.

## Re-score (Python 3 standard library only, no GPU)

    python3 verdict_5b.py --selftest
    python3 verdict_5b.py --e4b answers_run5b_e4b --prefix out/r

`out/r_verdict.md` and `out/r_e4b_report.md` should be byte-identical to `gpu_run5b_kaggle_verdict.md`
and `gpu_run5b_kaggle_e4b_report.md` (A − P accuracy +0.054 [+0.017, +0.090]; rejected-path recall A 1.00, P 0.68).

## Re-generate answers (GPU)

    python3 gpu_coldseat.py --kit kit_swe/KIT_swe.json --arms APC

Settings are in `PREREG_5b.md`, the registration, which was committed before the first answer. The sampling
temperature is 1.0, so a re-run reproduces the distribution, not the exact text.

## Contents
- `kit_swe/KIT_swe.json`: the three arms as the model saw them (sha256 98f06a7b…, as registered).
- `kit_swe/ANSWER_KEY_swe_private.json`: the answer key, kept hidden from the models during the runs (hence
  the name) and published here. The scorer's operative rubric is the regex lists in `score_k2.py`, written from this key.
- `kit_swe/SOURCE_NOTES.md`, `select_swe.py`: which public SWE-agent trajectories the kit came from.
- `score.py`, `batch_score.py`: the scorer. Kit 1's item lists name private audit targets, so they were
  removed. Kit 2's lists are installed by `score_k2.py`, and the scoring code is unchanged.
- `answers_run5b_e4b/`: the 60 raw answers and the job manifest.

Not included: kit 1 (private security-audit working memory) and the RRC implementation.

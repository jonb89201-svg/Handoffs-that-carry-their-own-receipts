#!/usr/bin/env python3
"""
Batch-score a GPU cold-seat run (runs.zip or a runs/ dir from gpu_coldseat.py) against the pre-registered key.

Per answer: Q2/Q3 recall + reason/blocker (score.py matchers), Q4 valid don't-retry items, Q1 terminal
correctness (heuristic), Q5 consistency / refusal, reject revival, invented specifics (Arm C), truncation,
and the model's OWN token counts from manifest.jsonl.
Per arm: mean with a 95% bootstrap CI; A-B difference with a bootstrap CI.

HEURISTIC fields (q1_*, q5, revival) are pattern-based: spot-check the per-answer CSV by hand before
quoting them. Q2-Q4 use the matchers proven by teeth claims SCORER / SCORER_PROSE.

Usage: python3 batch_score.py runs.zip|runs_dir [--out report.md] [--csv answers.csv] [--seed 7]
"""

from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import random
import re
import statistics
import sys
import tempfile
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from score import OPEN, REJ, score_list, split_questions  # noqa: E402

# research (non-TERMINAL) invariants: naming one of these as TERMINAL is a false-continuity error
RESEARCH_ITEMS = {}  # kit-1 items removed for publication; score_k2.activate() installs kit 2's
BACKGROUND = r"\b(following|after|previous|prior|failed|failures?|issues|limitations|challenges|lessons|noted|encountered)\b"
NEXT_OK = r"(?!x)x"  # kit-1 pattern removed; set by score_k2.activate()
NEXT_JUSTIFIED = r"(?!x)x"  # kit-1 pattern removed; set by score_k2.activate()
TERMINAL_REQUIRED = []  # kit-1 items removed; set by score_k2.activate()
REFUSAL = r"not in handoff"
RETRY_WORDS = r"\b(retry|revisit|re-?open|try again|resubmit|re-?attempt|pursue)\b"


# pre-registered audit scope (kit_v2/PREREG_v2.md): key filtered by ID; OPEN-A02 excluded (postdates the Sep 17 summary)
AUDIT_REJ = [x for x in REJ if x[0] in {"REJ-A01", "REJ-A02", "REJ-A03", "REJ-A04", "REJ-A05", "REJ-A06"}]
AUDIT_OPEN = [x for x in OPEN if x[0] == "OPEN-A01"]
AUDIT_RESEARCH = {k: v for k, v in RESEARCH_ITEMS.items() if k.startswith("INV-A")}
ARM_SCOPE = {"F": "audit", "G": "audit", "E": "audit"}


def q1_eval(q1, research=None):
    lines = q1.strip().splitlines()                                   # sections start with a newline
    body = "\n".join(lines[1:]) if len(lines) > 1 else q1               # skip the heading line
    m = re.search(r"claimed|measured earlier|\bresearch\b|not (yet )?terminal|non-terminal|only claimed", body, re.I)
    terminal_part = body[:m.start()] if m else body
    named = all(re.search(p, terminal_part, re.I) for p in TERMINAL_REQUIRED)   # kit 2 (score_k2) swaps the list
    false_term = sum(1 for p in (research or RESEARCH_ITEMS).values() if re.search(p, terminal_part, re.I))
    return (1.0 if (named and not false_term) else 0.0), false_term


def q5_eval(q5):
    refusal = re.search(REFUSAL, q5, re.I) is not None
    ok = re.search(NEXT_OK, q5, re.I) is not None or re.search(NEXT_JUSTIFIED, q5, re.I) is not None
    return (1.0 if ok and not refusal else 0.0), refusal, ok


def revival(qs):
    """A rejected path recommended as a next step (Q5), or Q4 saying to retry one."""
    q5 = qs.get(5, "")
    # a rejected path counts only where it is RECOMMENDED, not where it is cited as history
    live = " ".join(s for s in re.split(r"(?<=[.!?])\s+|\n", q5) if not re.search(BACKGROUND, s, re.I))
    _, _, rows5 = score_list(live, REJ)
    n = sum(1 for _, f, _ in rows5 if f)
    q4 = qs.get(4, "")
    n += sum(1 for ln in q4.splitlines() if re.search(RETRY_WORDS, ln, re.I) and not re.search(r"\bnot\b|don.?t|never", ln, re.I))
    return n


def score_answer(text, scope="full"):
    qs = split_questions(text)
    rej, opn = (AUDIT_REJ, AUDIT_OPEN) if scope == "audit" else (REJ, OPEN)
    q2h, q2r, _ = score_list(qs.get(2, ""), rej)
    q3h, q3b, _ = score_list(qs.get(3, ""), opn)
    q4 = qs.get(4, "")
    listed = "\n".join(ln for ln in q4.splitlines() if re.match(r"\s*(\d+[.)]|[-*])\s", ln))
    q4h, q4r, _ = score_list(listed or q4, rej)
    if scope == "audit":                           # nothing in scope is TERMINAL: correct iff no research item promoted
        _, false_term = q1_eval(qs.get(1, ""), AUDIT_RESEARCH)
        q1 = 1.0 if false_term == 0 else 0.0
    else:
        q1, false_term = q1_eval(qs.get(1, ""))
    q5, refused, q5_named = q5_eval(qs.get(5, ""))
    r = {"sections": len(qs), "scope": scope, "q1": q1, "false_terminal": false_term,
         "q2_recall": q2h / len(rej), "q2_reason": q2r / len(rej), "q3_recall": q3h / len(opn), "q3_blocker": q3b / len(opn),
         "q4_valid": min(q4r, 3) / 3, "q5": q5, "q5_refused": int(refused), "revival": revival(qs),
         "not_in_handoff": len(re.findall(REFUSAL, text, re.I)),
         "specifics": q2h + q3h}                                   # for Arm C: every specific is invented
    if scope == "audit":                           # Q5 excluded in audit scope (pre-registered)
        r["q5"] = float("nan")
        r["accuracy"] = statistics.mean([r["q1"], r["q2_recall"], r["q3_recall"], r["q4_valid"]])
        r["accuracy_noQ5"] = r["accuracy"]
        return r
    r["accuracy"] = statistics.mean([r["q1"], r["q2_recall"], r["q3_recall"], r["q4_valid"], r["q5"]])
    r["accuracy_noQ5"] = statistics.mean([r["q1"], r["q2_recall"], r["q3_recall"], r["q4_valid"]])
    return r


def boot_ci(xs, rng, n=4000):
    xs = [x for x in xs if x == x]                 # drop NaN (metric not applicable to this scope)
    if not xs:
        return (float("nan"),) * 3
    means = sorted(statistics.mean(rng.choice(xs) for _ in xs) for _ in range(n))
    return statistics.mean(xs), means[int(0.025 * n)], means[int(0.975 * n) - 1]


def boot_diff(a, b, rng, n=4000):
    if not a or not b:
        return (float("nan"),) * 3
    d = sorted(statistics.mean(rng.choice(a) for _ in a) - statistics.mean(rng.choice(b) for _ in b) for _ in range(n))
    return statistics.mean(a) - statistics.mean(b), d[int(0.025 * n)], d[int(0.975 * n) - 1]


def load_runs(path):
    if zipfile.is_zipfile(path):
        d = tempfile.mkdtemp(prefix="runs-")
        zipfile.ZipFile(path).extractall(d)
        path = d
    rows = []
    for man in glob.glob(os.path.join(path, "**", "manifest.jsonl"), recursive=True):
        base = os.path.dirname(man)
        seen = {}
        for line in open(man, encoding="utf-8"):
            line = line.strip()
            if line:
                rec = json.loads(line)
                seen[(rec["arm"], rec["i"])] = rec                  # last write wins (reruns append)
        for rec in seen.values():
            f = os.path.join(base, rec["file"])
            if os.path.exists(f):
                rec = dict(rec, **score_answer(open(f, encoding="utf-8", errors="replace").read(),
                                               ARM_SCOPE.get(rec["arm"], "full")))
                rec["path"] = os.path.relpath(f, path)
                rows.append(rec)
    return sorted(rows, key=lambda r: (r["arm"], r["i"]))


METRICS = ["accuracy", "accuracy_noQ5", "q1", "false_terminal", "q2_recall", "q2_reason", "q3_recall", "q3_blocker",
           "q4_valid", "q5", "q5_refused", "revival", "specifics", "tokens_out"]


def report(rows, seed):
    rng = random.Random(seed)
    arms = sorted({r["arm"] for r in rows})
    by = {a: [r for r in rows if r["arm"] == a] for a in arms}
    model = sorted({r.get("model", "?") for r in rows})
    out = [f"# Cold-seat GPU run: batch score\n", f"Model(s): {', '.join(model)} · answers: {len(rows)} · "
           f"arms: {', '.join(f'{a}={len(by[a])}' for a in arms)} · bootstrap seed {seed}\n",
           "## Handoff cost (MEASURED: the model's own tokenizer, prompt incl. questions)\n",
           "| arm | tokens_in | answers | truncated |", "|---|---|---|---|"]
    for a in arms:
        tin = sorted({r["tokens_in"] for r in by[a]})
        out.append(f"| {a} | {', '.join(map(str, tin))} | {len(by[a])} | {sum(1 for r in by[a] if r.get('truncated'))} |")
    out += ["\n## Per-arm means, 95% bootstrap CI\n", "| metric | " + " | ".join(arms) + " |",
            "|---|" + "---|" * len(arms)]
    for m in METRICS:
        cells = []
        for a in arms:
            mu, lo, hi = boot_ci([float(r[m]) for r in by[a]], rng)
            cells.append(f"{mu:.2f} [{lo:.2f}, {hi:.2f}]" if m != "tokens_out" else f"{mu:.0f} [{lo:.0f}, {hi:.0f}]")
        out.append(f"| {m} | " + " | ".join(cells) + " |")
    out.append("\nScope per arm: " + ", ".join(f"{a}={ARM_SCOPE.get(a, 'full')}" for a in arms))
    for x, y, label in [("A", "B", "frontier vs prose memo"), ("A", "D", "frontier vs bullet memo (same text)"),
                        ("F", "G", "audit: frontier vs bullet memo"), ("F", "E", "audit: frontier vs real compaction"),
                        ("G", "E", "audit: bullet memo vs real compaction")]:
        if x in by and y in by:
            out += [f"\n## {x} − {y} ({label}), 95% bootstrap CI\n", f"| metric | {x} − {y} | CI excludes 0? |", "|---|---|---|"]
            for m in ["accuracy", "q2_recall", "q3_recall", "false_terminal", "revival", "tokens_out"]:
                d, lo, hi = boot_diff([float(r[m]) for r in by[x]], [float(r[m]) for r in by[y]], rng)
                out.append(f"| {m} | {d:+.3f} [{lo:+.3f}, {hi:+.3f}] | {'yes' if lo > 0 or hi < 0 else 'no'} |")
    out += ["\n## Honesty notes",
            "- q1, false_terminal, q5, revival are HEURISTIC (pattern-based). Spot-check the CSV before quoting them.",
            "- Arm C `specifics` = rejected/open items it named. Its handoff contained none, so each one is invented.",
            "- Answers with sections < 5 were split badly or truncated. Hand-split before trusting them.",
            f"- Answers with <5 sections: {sum(1 for r in rows if r['sections'] < 5)} of {len(rows)}."]
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("runs")
    ap.add_argument("--out")
    ap.add_argument("--csv")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    rows = load_runs(a.runs)
    if not rows:
        sys.exit("no answers found (expected runs/<model>/manifest.jsonl + answer files)")
    rep = report(rows, a.seed)
    print(rep)
    if a.out:
        open(a.out, "w").write(rep)
    if a.csv:
        cols = ["arm", "i", "path", "tokens_in", "tokens_out", "truncated", "sections"] + METRICS[:-1] + ["not_in_handoff"]
        with open(a.csv, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)


if __name__ == "__main__":
    main()

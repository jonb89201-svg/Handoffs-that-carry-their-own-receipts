#!/usr/bin/env python3
"""PREREG_5b.md verdict: runs on kit SWE -> K1-K5, in one command. Scoring is NOT re-implemented: every per-answer number
comes from batch_score.py under the kit-SWE item lists (score_k2.activate()). Written and committed before any run-5b answer.

    python3 verdict_5b.py --m31b runs_gpu5b_31b/runs --e4b runs_gpu5b_e4b/runs [--no-write] [--prefix gpu_run5b]

  K1 gate (each model)          A accuracy >= 0.90                      (the frontier is readable on a second, public kit)
  K2 primary (each model)       A - P accuracy, bootstrap CI (seed 7)   -> A_AHEAD (CI > 0) / P_AHEAD (CI < 0) / TIE
  K3 (each model)               A - P q2_recall >= 0.20, CI excluding 0 (rejected paths are harder to extract from prose)
  K4 (each model)               C accuracy <= 0.15                      (the control cannot answer from repo names alone)
  K5 (each model)               false_terminal mean <= 0.10 in A and P (status is explicit in both arms)
Exit 0 if K1 holds on every model given, 1 otherwise, 2 no data. PROVISIONAL until the hand-read in PREREG_5b is done.
"""
import argparse, os, random, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import score_k2  # noqa: E402
from batch_score import boot_ci, boot_diff, load_runs, report, score_answer  # noqa: E402


def k2_class(d):
    return "A_AHEAD" if d[1] > 0 else "P_AHEAD" if d[2] < 0 else "TIE"


def verdict(tag, rows, seed):
    rng = random.Random(seed); by = {a: [r for r in rows if r["arm"] == a] for a in "APC"}
    col = lambda a, m: [float(r[m]) for r in by[a]]  # noqa: E731
    mean = lambda a, m: (sum(col(a, m)) / len(by[a])) if by[a] else float("nan")  # noqa: E731
    out = [f"## {tag.upper()} — {sorted({r.get('model', '?') for r in rows})}, answers " + ", ".join(f"{a}={len(v)}" for a, v in by.items())]
    if any(not by[a] for a in "APC"):
        return "\n".join(out + ["**INCOMPLETE: an arm is missing**"]) + "\n", False, None
    acc = {a: boot_ci(col(a, "accuracy"), rng) for a in "AP"}
    k1 = acc["A"][0] >= 0.90
    out.append(f"- **K1** A accuracy {acc['A'][0]:.2f} [{acc['A'][1]:.2f}, {acc['A'][2]:.2f}] (bar 0.90) → **{'HOLDS' if k1 else 'FAILS'}**")
    d = boot_diff(col("A", "accuracy"), col("P", "accuracy"), rng); cls = k2_class(d)
    out.append(f"- **K2** P accuracy {acc['P'][0]:.2f} [{acc['P'][1]:.2f}, {acc['P'][2]:.2f}]; A − P {d[0]:+.3f} [{d[1]:+.3f}, {d[2]:+.3f}] → **{cls}**")
    q2 = boot_diff(col("A", "q2_recall"), col("P", "q2_recall"), rng); k3 = q2[0] >= 0.20 and q2[1] > 0
    out.append(f"- **K3** q2_recall A {mean('A','q2_recall'):.2f} P {mean('P','q2_recall'):.2f}; A − P {q2[0]:+.3f} [{q2[1]:+.3f}, {q2[2]:+.3f}] → **{'HOLDS' if k3 else 'FAILS'}**")
    k4 = mean("C", "accuracy") <= 0.15
    out.append(f"- **K4** C accuracy {mean('C','accuracy'):.2f} (bar 0.15) → **{'HOLDS' if k4 else 'FAILS'}**")
    k5 = mean("A", "false_terminal") <= 0.10 and mean("P", "false_terminal") <= 0.10
    out.append(f"- **K5** false_terminal A {mean('A','false_terminal'):.2f} P {mean('P','false_terminal'):.2f} (bar 0.10) → **{'HOLDS' if k5 else 'FAILS'}**")
    out.append("- informational: " + "; ".join(f"{m} " + ", ".join(f"{a} {mean(a, m):.2f}" for a in "APC")
                                           for m in ("q1", "q2_reason", "q3_recall", "q3_blocker", "q4_valid", "q5", "revival"))
               + "; tokens_in " + ", ".join(f"{a} {sorted({r['tokens_in'] for r in by[a]})}" for a in "APC"))
    return "\n".join(out) + "\n", k1, cls


def scored(path):
    score_k2.activate()
    try:
        return load_runs(path)
    finally:
        score_k2.deactivate()


def selftest():
    """Known cases from the kit's own ceiling fixtures completed with Q4/Q5 (scored under score_k2): A vs P ties at the ceiling;
    A-fixture vs an all-refusal P is A_AHEAD and passes K1; an all-refusal A fails K1."""
    def fx(n):          # the ceiling fixture, with Q4 = its first three rejected clauses and Q5 = the arm's stated next step
        t = open(os.path.join(HERE, "kit_swe", n), encoding="utf-8").read()
        rej = [ln for ln in t.split("2. Rejected:")[1].split("3. Open:")[0].splitlines() if ln.startswith("- ")][:3]
        return t.replace("4. NOT IN HANDOFF", "4. Do not retry:\n" + "\n".join(rej)).replace(
            "5. NOT IN HANDOFF", "5. Next: apply the SPF2IP one-line fix by another means than the edit tool")
    refuse = "1. NOT IN HANDOFF\n2. NOT IN HANDOFF\n3. NOT IN HANDOFF\n4. NOT IN HANDOFF\n5. NOT IN HANDOFF\n"
    score_k2.activate()
    try:
        ra, rp, rr = score_answer(fx("_FIXTURE_swe_armA_verbatim.md")), score_answer(fx("_FIXTURE_swe_armP_verbatim.md")), score_answer(refuse)
    finally:
        score_k2.deactivate()
    mk = lambda arm, r: [dict(r, arm=arm, i=i, tokens_in=0, model="fixture") for i in range(20)]  # noqa: E731
    _, g1, c1 = verdict("fx", mk("A", ra) + mk("P", rp) + mk("C", rr), 7)
    _, g2, c2 = verdict("fx", mk("A", ra) + mk("P", rr) + mk("C", rr), 7)
    _, g3, _ = verdict("fx", mk("A", rr) + mk("P", ra) + mk("C", rr), 7)
    assert ra["accuracy"] == rp["accuracy"] == 1.0, (ra, rp)
    assert (c1, c2) == ("TIE", "A_AHEAD") and g2 is True and g3 is False, (c1, c2, g1, g2, g3)
    print("SELFTEST OK: fixtures A=P -> TIE, P refuses -> A_AHEAD (K1 holds), A refuses -> K1 fails")


def main():
    if "--selftest" in sys.argv:
        return selftest()
    ap = argparse.ArgumentParser(); ap.add_argument("--m31b"); ap.add_argument("--e4b"); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--prefix", default=os.path.join(HERE, "gpu_run5b")); ap.add_argument("--no-write", action="store_true"); a = ap.parse_args()
    texts, ok_all, any_data = ["# Run 5b — PREREG_5b verdict (kit SWE, score_k2; PROVISIONAL until hand-read)\n"], True, False
    for tag, path in (("31b", a.m31b), ("e4b", a.e4b)):
        if not path:
            continue
        rows = scored(path)
        if not rows:
            texts.append(f"## {tag}: no answers found\n"); ok_all = False; continue
        any_data = True; t, ok, _ = verdict(tag, rows, a.seed); texts.append(t); ok_all &= ok
        if not a.no_write:
            score_k2.activate()
            try:
                open(f"{a.prefix}_{tag}_report.md", "w").write(report(rows, a.seed))
            finally:
                score_k2.deactivate()
    texts.append(f"\n**K1 on every model given: {'HOLDS' if ok_all else 'FAILS'}**")
    text = "\n".join(texts); print(text)
    if not any_data:
        sys.exit(2)
    if not a.no_write:
        open(f"{a.prefix}_verdict.md", "w").write(text + "\n")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()

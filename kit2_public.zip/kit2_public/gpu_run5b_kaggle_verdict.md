# Run 5b — PREREG_5b verdict (kit SWE, score_k2; PROVISIONAL until hand-read)

## E4B — ['google/gemma-4-E4B-it'], answers A=20, P=20, C=20
- **K1** A accuracy 0.91 [0.89, 0.94] (bar 0.90) → **HOLDS**
- **K2** P accuracy 0.86 [0.84, 0.88]; A − P +0.054 [+0.017, +0.090] → **A_AHEAD**
- **K3** q2_recall A 1.00 P 0.68; A − P +0.319 [+0.154, +0.504] → **HOLDS**
- **K4** C accuracy 0.00 (bar 0.15) → **HOLDS**
- **K5** false_terminal A 0.00 P 0.00 (bar 0.10) → **HOLDS**
- informational: q1 A 1.00, P 1.00, C 0.00; q2_reason A 1.00, P 0.66, C 0.00; q3_recall A 1.00, P 1.00, C 0.00; q3_blocker A 1.00, P 1.00, C 0.00; q4_valid A 0.57, P 0.62, C 0.00; q5 A 1.00, P 1.00, C 0.00; revival A 1.00, P 1.00, C 0.00; tokens_in A [1500], P [1208], C [191]


**K1 on every model given: HOLDS**
